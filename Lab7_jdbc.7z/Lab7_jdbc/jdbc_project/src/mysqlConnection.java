import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class mysqlConnection {

	public static void main(String[] args) 
	{
		try 
		{
            Class.forName("com.mysql.jdbc.Driver").newInstance();
        } catch (Exception ex) {/* handle the error*/}
        
        try 
        {
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/test","root","Braude");
            //Connection conn = DriverManager.getConnection("jdbc:mysql://192.168.3.68/test","root","Root");
            System.out.println("SQL connection succeed");
           // createTableCourses(conn);
            printCourses(conn);
            updatePrice(conn,999,387);
            updatePrices(conn);
            increasePrices(conn);
     	} catch (SQLException ex) 
     	    {/* handle any errors*/
     		
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
            }
   	}
	
	public static void increasePrices(Connection con){
		Statement stmt;
		try {
			stmt = con.createStatement();
			
			printTable(con);
			stmt.executeUpdate("update flights set price = price + 50 where distance >  1000");
			printTable(con);
	 		 
		} catch (SQLException e) {	e.printStackTrace();}
	}
	
	public static void printTable(Connection con){
		Statement stmt;
		try {
			stmt = con.createStatement();
			
			ResultSet rs = stmt.executeQuery("SELECT * FROM flights;");
			System.out.println("\n------TABLE FLIGHTS VALUES-----\n");
	 		while(rs.next())
	 		{
				 System.out.println(rs.getInt(1)+"  " +rs.getString(2) + " " + rs.getString(3)+"  " +rs.getInt(4) + " " + rs.getFloat(5));
			} 
			rs.close();	
			
		} catch (SQLException e) {	e.printStackTrace();}
	}
	
	public static void printRow(Connection con, int num){
		Statement stmt;
		try {
			stmt = con.createStatement();
			
			ResultSet rs = stmt.executeQuery("SELECT * FROM flights where num =" + num);
			System.out.println("------ROW VALUES-----");
	 		while(rs.next())
	 		{
				 System.out.println(rs.getInt(1)+"  " +rs.getString(2) + " " + rs.getString(3)+"  " +rs.getInt(4) + " " + rs.getFloat(5));
			} 
			rs.close();	
			
		} catch (SQLException e) {	e.printStackTrace();}
		
	}
	public static void updatePrices(Connection con){
		System.out.println("CHANGING FLIGHTS PRICES TO FILE:\n");

		try 
		{
			Statement stmt;
			stmt = con.createStatement();
			PreparedStatement updatePrice = con.prepareStatement("UPDATE flights SET price = ? WHERE num= ?");
			
			System.out.println("\nOLD TABLE:\n");

			printTable(con);
			try(BufferedReader br = new BufferedReader(new FileReader("flights.txt"))) {
			    String line = br.readLine();

			    while (line != null) {
			    	
			    		String[] fields=line.split("\t");
			    		int fNum = Integer.parseInt(fields[0]);
			    		String[] prices = fields[4].split(",");
			    		float newPrice = Float.parseFloat(prices[1]);
			    		
			    		updatePrice.setFloat(1, newPrice);
			    		updatePrice.setInt(2,fNum);
			    		updatePrice.executeUpdate();
			    		line = br.readLine();
			   }
			    
				System.out.println("\nNEW TABLE:\n");

			printTable(con);

			    
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
			
			
		} catch (SQLException e) {e.printStackTrace();}
	}
	public static void printCourses(Connection con)
	{
		Statement stmt;
		try 
		{
			stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT * FROM courses;");
	 		while(rs.next())
	 		{
				 // Print out the values
				 System.out.println(rs.getString(1)+"  " +rs.getString(2));
			} 
			rs.close();
			//stmt.executeUpdate("UPDATE course SET semestr=\"W08\" WHERE num=61309");
		} catch (SQLException e) {e.printStackTrace();}
	}

	
	public static void createTableCourses(Connection con){
		Statement stmt;
		try {
			stmt = con.createStatement();
			stmt.executeUpdate("create table courses(num int, name VARCHAR(40), semestr VARCHAR(10));");
			stmt.executeUpdate("load data local infile \"courses.txt\" into table courses");
	 		
		} catch (SQLException e) {	e.printStackTrace();}
		 		
	}
	public static void updatePrice(Connection con, float price, int fNum)
	{
		
		System.out.println("CHANGING FLIGHT 387 PRICE:\n");
		Statement stmt;
		try {
			stmt = con.createStatement();
			
			printRow(con, 387);
			PreparedStatement updatePrice = con.prepareStatement("UPDATE flights SET price = ? WHERE num= ?");
			updatePrice.setFloat(1,price);
			updatePrice.setInt(2,fNum);
			updatePrice.executeUpdate();
			printRow(con,387);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	
}


